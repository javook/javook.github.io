/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ir.javahosting;

import javax.servlet.*;
import java.sql.*;

/**
 *
 * @author mnm
 */

public class listner implements ServletContextListener {

    public void contextInitialized(ServletContextEvent event) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/test?useUnicode=true&characterEncoding=UTF-8", "root", "pass");
            ServletContext ctx = event.getServletContext();
            ctx.setAttribute("mycon", con);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void contextDestroyed(ServletContextEvent arg0) {
    }
}
